<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Superadmin\\Providers\\SuperadminServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Superadmin\\Providers\\SuperadminServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);